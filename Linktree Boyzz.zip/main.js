const login = document.getElementById('login');
const nama = document.getElementById('nama');
const halaman = document.getElementById('halaman');
const geser = document.getElementById('geser');

halaman.style.display='none';
geser.style.display='none';

login.classList.add('animate__animated', 'animate__bounceInUp',);


/** login**/
function button() {
  if (nama.value=='') {
    Swal.fire({
  position: "center",
  icon: "error",
  title: "Nama Tidak Boleh Kosong",
  showConfirmButton: false,
  timer: 2000
});
  } else {
  halaman.style.display='flex';
  geser.style.display='block';
  login.style.display ='none';

    Swal.fire({
  position: "center",
  icon: "success",
  title: "Halo "+nama.value+" 🤗🤗",
  showConfirmButton: false,
  timer: 2000
});

    window.addEventListener('click',() => {
      document.getElementById('backsound').play();
    },
    )
  }
}

